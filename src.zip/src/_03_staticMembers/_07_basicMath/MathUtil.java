package _03_staticMembers._07_basicMath;


public class MathUtil {

    public static Double sumNumbers(double firstNumber, double secondNumber){
        return firstNumber + secondNumber;
    }

    public static Double subtractNumbers(double firstNumber, double secondNumber){
        return firstNumber - secondNumber;
    }

    public static Double multiplyNumbers(double firstNumber, double secondNumber){
        return firstNumber * secondNumber;
    }

    public static Double divideNumbers(double firstNumber, double secondNumber){
        return firstNumber / secondNumber;
    }

    public static Double percentage(double firstNumber, double secondNumber){
        return firstNumber * secondNumber / 100;
    }


}
