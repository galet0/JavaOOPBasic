package _03_staticMembers._06_planckConstant;

/**
 * Created by User on 28.06.2016.
 */
public class PlanckConstantMain {
    public static void main(String[] args) {
        System.out.println(Calculation.reducedPlanckConstant());
    }
}
