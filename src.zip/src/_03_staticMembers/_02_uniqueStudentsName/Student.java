package _03_staticMembers._02_uniqueStudentsName;

/**
 * Created by User on 27.06.2016.
 */
public class Student {
    private String name;

    public Student(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
