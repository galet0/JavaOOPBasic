package _02_Methods._06_PrimeChecker;

/**
 * Created by User on 26.06.2016.
 */
public class PrimeCheckerMain {
    public static void main(String[] args) {

    }
}
