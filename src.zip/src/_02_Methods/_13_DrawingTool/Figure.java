package _02_Methods._13_DrawingTool;

/**
 * Created by User on 26.06.2016.
 */
public interface Figure {
    void draw();
}
