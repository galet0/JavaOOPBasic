package _01_DefiningClasses._06_RawData;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class _06_RawDataMain {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(reader.readLine());

    }
}
