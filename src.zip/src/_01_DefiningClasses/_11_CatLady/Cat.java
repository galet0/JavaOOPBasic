package _01_DefiningClasses._11_CatLady;

/**
 * Created by User on 24.06.2016.
 */
public abstract class Cat {
    String name;

    public Cat(String name) {
        this.name = name;
    }
}
